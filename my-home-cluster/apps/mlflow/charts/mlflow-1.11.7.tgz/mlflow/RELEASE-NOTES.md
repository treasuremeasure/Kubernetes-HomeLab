# Changelog

- **Changed**: Update burakince/mlflow image version to 3.16.0
    - [Upstream Project](https://hub.docker.com/r/burakince/mlflow)
- **Changed**: Update dependency postgresql from 18.8.13 to 18.8.17
    - [ArtifactHub](https://artifacthub.io/packages/helm/bitnami/postgresql)
